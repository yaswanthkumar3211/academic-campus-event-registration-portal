# 🎓 Smart Campus Event Management System

A full-stack web application for colleges/universities to manage campus events, workshops, and seminars. Students can browse, register, and rate events; admins can create, manage, and analyse them.

---

## 📸 Overview

| Role    | Key Pages |
|---------|-----------|
| Student | Browse Events, Register, My Registrations, Rate Events |
| Admin   | Dashboard Stats, Manage Events (CRUD), View Registrations, View Feedback |

---

## 🛠️ Tech Stack

| Layer      | Technology |
|------------|-----------|
| Backend    | Node.js 18+, Express 4 |
| Database   | MySQL 8+ |
| Frontend   | HTML5, CSS3, Vanilla ES6 |
| Auth       | express-session (cookie-based) |
| Validation | express-validator |
| Security   | bcryptjs password hashing |
| ORM/DB     | mysql2/promise (raw SQL + connection pool) |

---

## 📁 Project Structure

```
smart-campus-events/
├── server.js                  ← Express entry point
├── db.js                      ← MySQL connection pool
├── .env                       ← Environment variables (edit this!)
├── schema.sql                 ← Database schema + seed data
├── package.json
│
├── middleware/
│   ├── auth.js                ← Session-based admin auth guard
│   └── errorHandler.js        ← Global error handler
│
├── routes/
│   ├── auth.js                ← POST /api/auth/login|logout, GET /api/auth/me
│   ├── events.js              ← Full CRUD + search + stats
│   ├── registrations.js       ← Student registration + admin view
│   └── feedback.js            ← Submit + view feedback
│
└── public/
    ├── index.html             ← Student: Browse Events
    ├── my-events.html         ← Student: My Registrations + Feedback
    ├── css/
    │   ├── style.css          ← Student portal styles
    │   └── admin.css          ← Admin dashboard styles
    ├── js/
    │   ├── utils.js           ← Shared: toast, date format, API helpers
    │   ├── main.js            ← Student: browse + register
    │   ├── my-events.js       ← Student: my events + feedback
    │   └── admin.js           ← Admin: dashboard, CRUD, stats
    └── admin/
        ├── login.html         ← Admin login page
        └── dashboard.html     ← Admin dashboard (all-in-one SPA)
```

---

## ⚡ Quick Start

### Prerequisites
- **Node.js 18+** — https://nodejs.org
- **MySQL 8+** — https://dev.mysql.com/downloads/
  *(or use XAMPP / WAMP which includes MySQL)*

---

### Step 1 — Set up the Database

Open MySQL Workbench, phpMyAdmin, or MySQL CLI and run:

```sql
SOURCE path/to/smart-campus-events/schema.sql;
```

This creates the `smart_campus_events` database, all tables, and seeds sample events.

---

### Step 2 — Configure Environment

Edit the `.env` file:

```env
PORT=3000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password   ← CHANGE THIS
DB_NAME=smart_campus_events
SESSION_SECRET=any_random_long_string
```

---

### Step 3 — Install & Run

```bash
cd smart-campus-events
npm install
npm start
```

**Development mode (auto-restart on changes):**
```bash
npm run dev
```

---

### Step 4 — Open in Browser

| URL | Description |
|-----|-------------|
| `http://localhost:3000` | Student portal — browse & register |
| `http://localhost:3000/my-events.html` | Student — view registered events |
| `http://localhost:3000/admin/login.html` | Admin login |
| `http://localhost:3000/admin/dashboard.html` | Admin dashboard |

**Default admin credentials:**
- Username: `admin`
- Password: `Admin@123`

---

## 🔌 REST API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Admin login `{ username, password }` |
| POST | `/api/auth/logout` | Admin logout |
| GET  | `/api/auth/me` | Get current session |

### Events (Public)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events` | Browse events. Query: `?type=&department=&date=&search=&page=&limit=&upcoming=true` |
| GET | `/api/events/meta` | Get filter options (types, departments) |
| GET | `/api/events/:id` | Event detail with stats |

### Events (Admin — requires session)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/events/admin/all` | All events with filters |
| GET    | `/api/events/admin/stats` | Dashboard aggregate stats |
| POST   | `/api/events` | Create event |
| PUT    | `/api/events/:id` | Update event |
| DELETE | `/api/events/:id` | Delete event (cascades registrations) |

### Registrations
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/registrations` | Register student for event |
| GET  | `/api/registrations/student/:email` | Student's registration history |
| GET  | `/api/registrations/event/:eventId` | All registrations for event (admin) |
| DELETE | `/api/registrations/:id` | Cancel registration `{ email }` |

### Feedback
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/feedback` | Submit rating (1–5) + comment |
| GET  | `/api/feedback/event/:eventId` | Public feedback for event |
| GET  | `/api/feedback/admin/all` | All feedback (admin) |

---

## ✅ Validation Rules

| Field | Rule |
|-------|------|
| `student_name` | Required, 2–150 chars |
| `student_email` | Valid email format |
| `phone` | Indian 10-digit mobile (starts with 6–9) |
| `year_of_study` | Integer 1–5 |
| `event_date` | Valid ISO date |
| `event_time` | HH:MM format |
| `max_seats` | Positive integer |
| `rating` | Integer 1–5 |

---

## 🔒 Security Features

- **Password hashing** via bcryptjs (cost factor 10)
- **Session-based auth** with HTTP-only cookies (8-hour expiry)
- **Admin route guards** on all `/api/events/admin/*` and write routes
- **Duplicate registration** prevention at DB level (UNIQUE constraint)
- **Seat overflow** checked in real-time before insert
- **HTML escaping** on all user-generated content to prevent XSS

---

## 🗄️ Database Schema Summary

```
admins          id, username, password (bcrypt), full_name
events          id, title, description, event_date, event_time, venue,
                department, event_type (enum), max_seats, speaker_name,
                speaker_bio, is_active, created_by → admins.id
registrations   id, event_id → events.id, student_name, student_email,
                student_id, department, year_of_study, phone
                UNIQUE (event_id, student_email)
feedback        id, event_id → events.id, student_email, rating (1-5),
                comments
                UNIQUE (event_id, student_email)
```

---

## 🌟 Feature Highlights

- **Real-time seat tracking** with progress bar on each card
- **Global error handler** middleware (equivalent to Spring's `@ControllerAdvice`)
- **Aggregate SQL queries** for dashboard stats (COUNT, AVG, GROUP BY)
- **Search + multi-filter** on both student portal and admin panel
- **Feedback only for verified attendees** of past events
- **Responsive design** — works on mobile, tablet, desktop
- **Skeleton loading states** on all async loads

---

## 🧪 Testing the App

1. **Browse events** → `http://localhost:3000`
2. **Register** for any event (use email `test@college.edu`)
3. **View your registrations** → My Registrations → enter `test@college.edu`
4. **Admin login** → Create / Edit / Delete events
5. **Dashboard stats** → View aggregated charts
6. **View registrations** by event in admin panel
