// middleware/auth.js — Session-based admin authentication

/**
 * requireAdmin — protects admin API routes.
 * Returns 401 JSON if the request has no active admin session.
 */
const requireAdmin = (req, res, next) => {
  if (req.session && req.session.admin) {
    return next();
  }
  return res.status(401).json({
    success: false,
    message: 'Unauthorised. Please log in as an administrator.',
  });
};

/**
 * requireAdminPage — protects admin HTML pages.
 * Redirects to /admin/login.html instead of returning JSON.
 */
const requireAdminPage = (req, res, next) => {
  if (req.session && req.session.admin) {
    return next();
  }
  return res.redirect('/admin/login.html');
};

module.exports = { requireAdmin, requireAdminPage };
