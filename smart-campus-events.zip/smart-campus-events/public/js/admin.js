// admin.js — Admin dashboard: events CRUD, stats, registrations, feedback
'use strict';

let adminCurrentPage = 1;
let deleteEventId    = null;
let isEditMode       = false;

// ── Auth guard ────────────────────────────────────────────────
(async () => {
  try {
    const { data } = await apiFetch('/api/auth/me');
    if (!data.success) {
      window.location.href = '/admin/login.html';
      return;
    }
    const admin = data.admin;
    document.getElementById('admin-name').textContent = admin.full_name || admin.username;
    const initials = (admin.full_name || admin.username).split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);
    document.getElementById('admin-avatar-initials').textContent = initials;
    showPage('dashboard');
  } catch {
    window.location.href = '/admin/login.html';
  }
})();

// ── Page navigation ───────────────────────────────────────────
const PAGE_TITLES = {
  dashboard:     'Dashboard Overview',
  events:        'Manage Events',
  registrations: 'Event Registrations',
  feedback:      'Student Feedback',
};

function showPage(page) {
  ['dashboard','events','registrations','feedback'].forEach(p => {
    document.getElementById(`page-${p}`).classList.toggle('hidden', p !== page);
  });

  document.querySelectorAll('.sidebar-link[data-page]').forEach(l => {
    l.classList.toggle('active', l.dataset.page === page);
  });

  document.getElementById('topbar-title').textContent = PAGE_TITLES[page];
  document.getElementById('topbar-add-btn').style.display = page === 'events' ? 'flex' : 'none';

  if (page === 'dashboard')     loadDashboard();
  if (page === 'events')        loadAdminEvents(1);
  if (page === 'registrations') loadRegistrationsPage();
  if (page === 'feedback')      loadFeedback();
}

// ── Dashboard ─────────────────────────────────────────────────
async function loadDashboard() {
  try {
    const { data } = await apiFetch('/api/events/admin/stats');
    if (!data.success) return;

    const { summary, byType, byDept, topEvents } = data.data;

    document.getElementById('dash-total-events').textContent    = summary.total_events || 0;
    document.getElementById('dash-upcoming').textContent        = summary.upcoming_events || 0;
    document.getElementById('dash-registrations').textContent   = summary.total_registrations || 0;
    document.getElementById('dash-avg-rating').textContent      = summary.avg_rating ? `${summary.avg_rating}★` : '—';
    document.getElementById('badge-events').textContent         = summary.upcoming_events || 0;

    // By type mini chart
    const maxReg = Math.max(...byType.map(t => t.registrations || 0), 1);
    document.getElementById('chart-by-type').innerHTML = byType.map(t => `
      <div class="mini-bar-row">
        <span class="mini-bar-label">${capitalize(t.event_type)}</span>
        <div class="mini-bar-track">
          <div class="mini-bar-fill" style="width:${Math.round((t.registrations / maxReg) * 100)}%"></div>
        </div>
        <span class="mini-bar-val">${t.registrations}</span>
      </div>`).join('') || '<p style="color:#8a8178;font-size:.85rem">No data yet.</p>';

    // By dept chart
    const maxDept = Math.max(...byDept.map(d => d.registrations || 0), 1);
    document.getElementById('chart-by-dept').innerHTML = byDept.map(d => `
      <div class="mini-bar-row">
        <span class="mini-bar-label" style="width:130px">${d.department}</span>
        <div class="mini-bar-track">
          <div class="mini-bar-fill" style="width:${Math.round((d.registrations / maxDept) * 100)}%;background:linear-gradient(90deg,#c8912a,#e4b05a)"></div>
        </div>
        <span class="mini-bar-val">${d.registrations}</span>
      </div>`).join('') || '<p style="color:#8a8178;font-size:.85rem">No data yet.</p>';

    // Top events table
    const tbody = document.getElementById('top-events-table');
    if (topEvents.length) {
      tbody.innerHTML = topEvents.map((ev, i) => `
        <tr>
          <td><strong>${i + 1}</strong>. ${escHtml(ev.title)}</td>
          <td><span class="badge badge-type" style="font-size:.7rem;text-transform:capitalize">${ev.event_type}</span></td>
          <td><strong>${ev.registrations}</strong></td>
        </tr>`).join('');
    } else {
      tbody.innerHTML = '<tr><td colspan="3" style="text-align:center;color:#8a8178;padding:16px">No data yet.</td></tr>';
    }
  } catch (err) {
    showToast('Failed to load dashboard stats.', 'error');
  }
}

// ── Load Admin Events Table ───────────────────────────────────
async function loadAdminEvents(page = 1) {
  adminCurrentPage = page;
  const tbody = document.getElementById('events-table-body');
  tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#8a8178;padding:24px"><i class="fa fa-spinner fa-spin"></i> Loading…</td></tr>';

  const params = new URLSearchParams({ page, limit: 10 });
  const search = document.getElementById('admin-search')?.value.trim();
  const type   = document.getElementById('admin-filter-type')?.value;
  const date   = document.getElementById('admin-filter-date')?.value;
  if (search) params.set('search', search);
  if (type)   params.set('type', type);
  if (date)   params.set('date', date);

  try {
    const { data } = await apiFetch(`/api/events/admin/all?${params}`);
    if (!data.success) { tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#c0392b;padding:24px">Failed to load events.</td></tr>'; return; }

    const events = data.data;
    if (!events.length) {
      tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#8a8178;padding:24px">No events found.</td></tr>';
      renderAdminPagination(data.pagination);
      return;
    }

    tbody.innerHTML = events.map((ev, idx) => {
      const pct      = Math.round((ev.registered_count / ev.max_seats) * 100);
      const isActive = ev.is_active == 1;
      const isPast   = isDatePast(ev.event_date);
      const offset   = (page - 1) * 10;

      return `
      <tr>
        <td style="color:#8a8178;font-size:.8rem">${offset + idx + 1}</td>
        <td>
          <div class="table-event-title">
            ${escHtml(ev.title)}
            <small>${formatDate(ev.event_date)}</small>
          </div>
        </td>
        <td style="font-size:.82rem;white-space:nowrap">${formatDate(ev.event_date)}<br><span style="color:#8a8178">${formatTime(ev.event_time)}</span></td>
        <td><span class="badge badge-type" style="font-size:.7rem;text-transform:capitalize;background:${typeColor(ev.event_type)}22;color:${typeColor(ev.event_type)}">${ev.event_type}</span></td>
        <td style="font-size:.82rem;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(ev.venue)}</td>
        <td style="font-size:.82rem">${ev.max_seats}</td>
        <td>
          <div style="font-size:.82rem;font-weight:600">${ev.registered_count}</div>
          <div style="height:3px;background:#f0ede8;border-radius:2px;margin-top:3px;width:60px">
            <div style="height:100%;border-radius:2px;background:${pct>=100?'#c0392b':pct>=80?'#d4850a':'#2c5f41'};width:${Math.min(pct,100)}%"></div>
          </div>
        </td>
        <td>
          <span class="badge ${isActive ? (isPast ? 'badge-warning' : 'badge-success') : ''}"
                style="${!isActive ? 'background:#f5f5f5;color:#8a8178' : ''}">
            ${isActive ? (isPast ? 'Completed' : 'Active') : 'Inactive'}
          </span>
        </td>
        <td>
          <div class="actions-cell">
            <button class="btn btn-ghost btn-sm btn-icon" title="View registrations"
              onclick="quickViewRegistrations(${ev.id}, '${escHtml(ev.title).replace(/'/g,"\\'")}')">
              <i class="fa fa-users"></i>
            </button>
            <button class="btn btn-ghost btn-sm btn-icon" title="Edit"
              onclick="openEditModal(${ev.id})">
              <i class="fa fa-pencil"></i>
            </button>
            <button class="btn btn-danger btn-sm btn-icon" title="Delete"
              onclick="openDeleteModal(${ev.id}, '${escHtml(ev.title).replace(/'/g,"\\'")}')">
              <i class="fa fa-trash"></i>
            </button>
          </div>
        </td>
      </tr>`;
    }).join('');

    renderAdminPagination(data.pagination);
  } catch {
    tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#c0392b;padding:24px">Failed to load.</td></tr>';
  }
}

function renderAdminPagination(pagination) {
  const { page, totalPages } = pagination;
  const container = document.getElementById('admin-pagination');
  if (!container || totalPages <= 1) { if (container) container.innerHTML = ''; return; }

  let html = `<button class="page-btn" onclick="loadAdminEvents(${page-1})" ${page<=1?'disabled':''}>‹</button>`;
  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="page-btn ${i===page?'active':''}" onclick="loadAdminEvents(${i})">${i}</button>`;
  }
  html += `<button class="page-btn" onclick="loadAdminEvents(${page+1})" ${page>=totalPages?'disabled':''}>›</button>`;
  container.innerHTML = html;
}

function clearAdminFilters() {
  document.getElementById('admin-search').value       = '';
  document.getElementById('admin-filter-type').value  = '';
  document.getElementById('admin-filter-date').value  = '';
  loadAdminEvents(1);
}

// ── Event Modal (Add / Edit) ──────────────────────────────────
function openEventModal() {
  isEditMode = false;
  document.getElementById('event-modal-title').textContent = 'Add New Event';
  document.getElementById('event-save-btn').innerHTML = '<i class="fa fa-plus"></i> Create Event';
  document.getElementById('edit-event-id').value = '';
  clearEventForm();
  openModal('event-modal');
}

async function openEditModal(eventId) {
  try {
    const { data } = await apiFetch(`/api/events/${eventId}`);
    if (!data.success) { showToast('Failed to load event.', 'error'); return; }

    isEditMode = true;
    const ev   = data.data;
    document.getElementById('event-modal-title').textContent = 'Edit Event';
    document.getElementById('event-save-btn').innerHTML = '<i class="fa fa-save"></i> Update Event';
    document.getElementById('edit-event-id').value = ev.id;

    document.getElementById('ev-title').value       = ev.title;
    document.getElementById('ev-description').value = ev.description;
    document.getElementById('ev-date').value         = ev.event_date?.split('T')[0] || '';
    document.getElementById('ev-time').value         = ev.event_time?.slice(0,5) || '';
    document.getElementById('ev-venue').value        = ev.venue;
    document.getElementById('ev-dept').value         = ev.department;
    document.getElementById('ev-type').value         = ev.event_type;
    document.getElementById('ev-seats').value        = ev.max_seats;
    document.getElementById('ev-speaker').value      = ev.speaker_name || '';
    document.getElementById('ev-speaker-bio').value  = ev.speaker_bio  || '';
    document.getElementById('ev-active').value       = ev.is_active;

    openModal('event-modal');
  } catch {
    showToast('Failed to load event details.', 'error');
  }
}

function clearEventForm() {
  ['ev-title','ev-description','ev-date','ev-time','ev-venue','ev-speaker','ev-speaker-bio'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
  document.getElementById('ev-dept').value   = '';
  document.getElementById('ev-type').value   = '';
  document.getElementById('ev-seats').value  = 100;
  document.getElementById('ev-active').value = 1;
}

function closeEventModal() { closeModalById('event-modal'); }

// ── Save Event ────────────────────────────────────────────────
async function saveEvent() {
  // Client-side validation
  const fields = [
    ['ev-title',       'err-ev-title', 'Title is required.'],
    ['ev-description', 'err-ev-desc',  'Description is required.'],
    ['ev-date',        'err-ev-date',  'Date is required.'],
    ['ev-time',        'err-ev-time',  'Time is required.'],
    ['ev-venue',       'err-ev-venue', 'Venue is required.'],
    ['ev-dept',        'err-ev-dept',  'Department is required.'],
    ['ev-type',        'err-ev-type',  'Event type is required.'],
    ['ev-seats',       'err-ev-seats', 'Max seats is required.'],
  ];

  let valid = true;
  fields.forEach(([inputId, errId]) => {
    const el  = document.getElementById(inputId);
    const err = document.getElementById(errId);
    el.classList.remove('error');
    err.classList.add('hidden');
    if (!el.value.trim()) {
      el.classList.add('error');
      err.textContent = fields.find(f => f[0] === inputId)[2];
      err.classList.remove('hidden');
      valid = false;
    }
  });
  if (!valid) return;

  const payload = {
    title:        document.getElementById('ev-title').value.trim(),
    description:  document.getElementById('ev-description').value.trim(),
    event_date:   document.getElementById('ev-date').value,
    event_time:   document.getElementById('ev-time').value,
    venue:        document.getElementById('ev-venue').value.trim(),
    department:   document.getElementById('ev-dept').value,
    event_type:   document.getElementById('ev-type').value,
    max_seats:    parseInt(document.getElementById('ev-seats').value),
    speaker_name: document.getElementById('ev-speaker').value.trim() || null,
    speaker_bio:  document.getElementById('ev-speaker-bio').value.trim() || null,
    is_active:    parseInt(document.getElementById('ev-active').value),
  };

  const btn = document.getElementById('event-save-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Saving…';

  try {
    const editId = document.getElementById('edit-event-id').value;
    const url    = isEditMode ? `/api/events/${editId}` : '/api/events';
    const method = isEditMode ? 'PUT' : 'POST';

    const { data } = await apiFetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });

    if (data.success) {
      showToast(data.message, 'success');
      closeEventModal();
      loadAdminEvents(isEditMode ? adminCurrentPage : 1);
    } else {
      const msg = data.errors ? data.errors.map(e => e.msg).join(', ') : data.message;
      showToast(msg, 'error');
    }
  } catch {
    showToast('Failed to save event.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = isEditMode ? '<i class="fa fa-save"></i> Update Event' : '<i class="fa fa-plus"></i> Create Event';
  }
}

// ── Delete ────────────────────────────────────────────────────
function openDeleteModal(eventId, title) {
  deleteEventId = eventId;
  document.getElementById('delete-event-name').textContent = `"${title}"`;
  openModal('delete-modal');
}

function closeDeleteModal() { closeModalById('delete-modal'); }

async function confirmDelete() {
  if (!deleteEventId) return;
  const btn = document.getElementById('confirm-delete-btn');
  btn.disabled = true;
  btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Deleting…';

  try {
    const { data } = await apiFetch(`/api/events/${deleteEventId}`, { method: 'DELETE' });
    if (data.success) {
      showToast('Event deleted successfully.', 'success');
      closeDeleteModal();
      loadAdminEvents(adminCurrentPage);
    } else {
      showToast(data.message, 'error');
    }
  } catch {
    showToast('Failed to delete event.', 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<i class="fa fa-trash"></i> Delete Event';
  }
}

// ── Registrations Page ────────────────────────────────────────
async function loadRegistrationsPage() {
  const sel = document.getElementById('reg-event-select');
  sel.innerHTML = '<option value="">— Choose an event —</option>';

  try {
    const { data } = await apiFetch('/api/events/admin/all?limit=100');
    if (!data.success) return;
    data.data.forEach(ev => {
      const opt = document.createElement('option');
      opt.value       = ev.id;
      opt.textContent = `${ev.title} (${formatDate(ev.event_date)})`;
      sel.appendChild(opt);
    });
  } catch {}
}

async function loadEventRegistrations() {
  const eventId = document.getElementById('reg-event-select').value;
  const tbody   = document.getElementById('reg-table-body');

  if (!eventId) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#8a8178;padding:24px">Select an event to view registrations.</td></tr>';
    return;
  }

  tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#8a8178;padding:24px"><i class="fa fa-spinner fa-spin"></i> Loading…</td></tr>';

  try {
    const { data } = await apiFetch(`/api/registrations/event/${eventId}`);
    if (!data.success || !data.data.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#8a8178;padding:24px">No registrations for this event.</td></tr>';
      return;
    }

    tbody.innerHTML = data.data.map((reg, i) => `
      <tr>
        <td>${i+1}</td>
        <td style="font-weight:600">${escHtml(reg.student_name)}</td>
        <td style="font-size:.82rem">${escHtml(reg.student_email)}</td>
        <td><code style="font-size:.8rem;background:#f7f3ec;padding:2px 7px;border-radius:4px">${escHtml(reg.student_id)}</code></td>
        <td style="font-size:.82rem">${escHtml(reg.department)}</td>
        <td>Year ${reg.year_of_study}</td>
        <td style="font-size:.82rem">${escHtml(reg.phone)}</td>
        <td style="font-size:.78rem;color:#8a8178">${new Date(reg.registered_at).toLocaleString('en-IN')}</td>
      </tr>`).join('');
  } catch {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#c0392b;padding:24px">Failed to load.</td></tr>';
  }
}

async function quickViewRegistrations(eventId, title) {
  showPage('registrations');
  await new Promise(r => setTimeout(r, 200)); // wait for DOM
  const sel = document.getElementById('reg-event-select');
  if (sel) {
    sel.value = eventId;
    loadEventRegistrations();
  }
}

// ── Feedback ──────────────────────────────────────────────────
async function loadFeedback() {
  const tbody = document.getElementById('feedback-table-body');
  tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#8a8178;padding:24px"><i class="fa fa-spinner fa-spin"></i> Loading…</td></tr>';

  try {
    const { data } = await apiFetch('/api/feedback/admin/all');
    if (!data.success || !data.data.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#8a8178;padding:24px">No feedback submitted yet.</td></tr>';
      return;
    }

    const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);

    tbody.innerHTML = data.data.map((f, i) => `
      <tr>
        <td>${i+1}</td>
        <td style="font-weight:600;max-width:220px">${escHtml(f.event_title)}</td>
        <td>${escHtml(f.student_name)}</td>
        <td style="color:#c8912a;font-size:1rem;letter-spacing:1px">${stars(f.rating)}</td>
        <td style="font-size:.82rem;color:#5a5246;max-width:240px">${escHtml(f.comments || '—')}</td>
        <td style="font-size:.78rem;color:#8a8178;white-space:nowrap">${new Date(f.submitted_at).toLocaleDateString('en-IN')}</td>
      </tr>`).join('');
  } catch {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#c0392b;padding:24px">Failed to load feedback.</td></tr>';
  }
}

// ── Logout ────────────────────────────────────────────────────
async function logout() {
  await apiFetch('/api/auth/logout', { method: 'POST' });
  window.location.href = '/admin/login.html';
}

// ── Sidebar toggle (mobile) ───────────────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ── Helpers ───────────────────────────────────────────────────
function capitalize(str) { return str.charAt(0).toUpperCase() + str.slice(1); }

function isDatePast(dateStr) {
  const today = new Date(); today.setHours(0,0,0,0);
  return new Date(dateStr + 'T00:00:00') < today;
}

function escHtml(str) {
  return String(str ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}
