// routes/auth.js — Admin authentication endpoints
const express = require('express');
const bcrypt  = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db      = require('../db');
const router  = express.Router();

// ─────────────────────────────
// POST /api/auth/login
// ─────────────────────────────
router.post(
  '/login',
  [
    body('username').trim().notEmpty().withMessage('Username is required.'),
    body('password').notEmpty().withMessage('Password is required.'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { username, password } = req.body;

    try {
      const [rows] = await db.query(
        'SELECT * FROM admins WHERE username = ?',
        [username]
      );

      if (rows.length === 0) {
        return res.status(401).json({ success: false, message: 'Invalid username or password.' });
      }

      const admin = rows[0];
      const match = await bcrypt.compare(password, admin.password);

      if (!match) {
        return res.status(401).json({ success: false, message: 'Invalid username or password.' });
      }

      // Create session
      req.session.admin = {
        id:        admin.id,
        username:  admin.username,
        full_name: admin.full_name,
      };

      return res.json({
        success:   true,
        message:   'Login successful.',
        admin:     { id: admin.id, username: admin.username, full_name: admin.full_name },
      });

    } catch (err) {
      next(err);
    }
  }
);

// ─────────────────────────────
// POST /api/auth/logout
// ─────────────────────────────
router.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ success: false, message: 'Logout failed.' });
    }
    res.clearCookie('connect.sid');
    return res.json({ success: true, message: 'Logged out successfully.' });
  });
});

// ─────────────────────────────
// GET /api/auth/me
// ─────────────────────────────
router.get('/me', (req, res) => {
  if (req.session && req.session.admin) {
    return res.json({ success: true, admin: req.session.admin });
  }
  return res.status(401).json({ success: false, message: 'Not authenticated.' });
});

module.exports = router;
