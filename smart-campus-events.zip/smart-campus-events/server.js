// server.js — Smart Campus Event Management System
// Node.js + Express + MySQL
// ──────────────────────────────────────────────
require('dotenv').config();
const express       = require('express');
const session       = require('express-session');
const cors          = require('cors');
const path          = require('path');

const authRoutes    = require('./routes/auth');
const eventRoutes   = require('./routes/events');
const regRoutes     = require('./routes/registrations');
const feedbackRoutes = require('./routes/feedback');
const { errorHandler, notFound } = require('./middleware/errorHandler');

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret:            process.env.SESSION_SECRET || 'campus_secret',
  resave:            false,
  saveUninitialized: false,
  cookie: {
    secure:   false,          // set true in production with HTTPS
    httpOnly: true,
    maxAge:   8 * 60 * 60 * 1000,  // 8 hours
  },
}));

// ─── Static Files ─────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));

// ─── API Routes ───────────────────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/events',        eventRoutes);
app.use('/api/registrations', regRoutes);
app.use('/api/feedback',      feedbackRoutes);

// ─── Admin page access check ──────────────────────────────────────────────
// Any request to /admin/* that isn't the login page requires a session cookie
// (The actual auth is enforced in each /api/... route via requireAdmin middleware)

// ─── Catch-all: serve index.html for client-side routing ──────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Error Handling ───────────────────────────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ─── Start ────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀  Smart Campus Events running at http://localhost:${PORT}`);
  console.log(`📋  Student portal  →  http://localhost:${PORT}`);
  console.log(`🔐  Admin dashboard →  http://localhost:${PORT}/admin/dashboard.html`);
  console.log(`    Default admin   →  admin / Admin@123\n`);
});

module.exports = app;
